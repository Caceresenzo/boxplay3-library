package caceresenzo.apps.boxplay.models.element;

public class VideoElement extends StoreElement {

	protected VideoElement(String identifier) {
		super(identifier);
	}
	
}