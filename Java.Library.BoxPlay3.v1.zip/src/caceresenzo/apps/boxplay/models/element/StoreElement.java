package caceresenzo.apps.boxplay.models.element;

public class StoreElement extends BoxPlayElement {
	
	protected StoreElement(String identifier) {
		super(identifier);
	}
	
}