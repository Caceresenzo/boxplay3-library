package caceresenzo.apps.boxplay.models.music;

import java.util.ArrayList;

@SuppressWarnings("serial")
public class MusicPlaylist extends ArrayList<MusicFile> {
	
	public MusicPlaylist() {
		super();
	}
	
}