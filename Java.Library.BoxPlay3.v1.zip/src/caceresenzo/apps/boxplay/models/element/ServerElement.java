package caceresenzo.apps.boxplay.models.element;

public class ServerElement extends BoxPlayElement {
	
	protected ServerElement(String identifier) {
		super(identifier);
	}
	
}