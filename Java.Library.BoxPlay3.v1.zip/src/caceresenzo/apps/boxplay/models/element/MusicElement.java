package caceresenzo.apps.boxplay.models.element;

public class MusicElement extends StoreElement {
	
	protected MusicElement(String identifier) {
		super(identifier);
	}
	
}