package caceresenzo.apps.boxplay.models.service;

import caceresenzo.apps.boxplay.models.element.StoreElement;

public class ServiceElement extends StoreElement {

	protected ServiceElement(String identifier) {
		super(identifier);
	}
	
}